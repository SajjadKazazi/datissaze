<?php

return [
    'success.add' => 'منو با موفقیت افزوده شد',
    'success.update' => 'منو با موفقیت ویرایش شد',
    'success.delete' => 'منو با موفقیت حذف شد',
];
