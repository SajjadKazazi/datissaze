<?php

namespace App\Repositories\Front;

use Prettus\Repository\Contracts\RepositoryInterface;

/**
 * Interface PortfolioRepository.
 *
 * @package namespace App\Repositories\\Admin;
 */
interface CooperatorRepository extends RepositoryInterface
{
    //
}
