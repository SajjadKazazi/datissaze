<?php

namespace App\Repository;

interface NewsRepositoryInterface extends EloquentRepositoryInterface
{

}
