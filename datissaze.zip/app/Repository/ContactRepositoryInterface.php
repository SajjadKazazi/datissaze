<?php

namespace App\Repository;

interface ContactRepositoryInterface extends EloquentRepositoryInterface
{

}
