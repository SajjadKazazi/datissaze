<?php

return [
    'success.add' => 'خبر با موفقیت افزوده شد',
    'success.update' => 'خبر با موفقیت ویرایش شد',
    'success.delete' => 'خبر با موفقیت حذف شد',
];
