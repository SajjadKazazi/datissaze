<?php

return [
    'success.add' => 'عضو با موفقیت افزوده شد',
    'success.update' => 'عضو با موفقیت ویرایش شد',
    'success.delete' => 'عضو با موفقیت حذف شد',
];
