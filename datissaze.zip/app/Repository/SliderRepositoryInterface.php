<?php

namespace App\Repository;

interface SliderRepositoryInterface extends EloquentRepositoryInterface
{

}
