<?php

namespace App\Repository;

interface ServiceRepositoryInterface extends EloquentRepositoryInterface
{

}
