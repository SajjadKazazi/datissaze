<?php

namespace App\Repository;

interface PortfolioRepositoryInterface extends EloquentRepositoryInterface
{

}
