<?php

return [
    'success.add' => 'پروژه با موفقیت افزوده شد',
    'success.update' => 'پروژه با موفقیت ویرایش شد',
    'success.delete' => 'پروژه با موفقیت حذف شد',
];
