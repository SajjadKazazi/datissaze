import "/resources/js/admin/assets/jquery.min";
import "/resources/js/admin/assets/bootstrap.bundle.min";
import "/resources/js/admin/assets/metisMenu.min";
import "/resources/js/admin/assets/simplebar.min";
// import "/resources/js/admin/assets/waves.min";
import "/resources/js/admin/assets/pace.min";
import "/resources/js/admin/assets/flatpickr.min";
import "/resources/js/admin/assets/apexcharts.min";
import "/resources/js/admin/assets/dashboard-light";
import "/resources/js/admin/assets/feather.min";
import "/resources/js/admin/assets/template";
import "/resources/js/admin/assets/app";

