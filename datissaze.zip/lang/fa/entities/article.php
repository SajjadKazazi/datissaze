<?php

return [
    'success.add' => 'مقاله با موفقیت افزوده شد',
    'success.update' => 'مقاله با موفقیت ویرایش شد',
    'success.delete' => 'مقاله با موفقیت حذف شد',
];
