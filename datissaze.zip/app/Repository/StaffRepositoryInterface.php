<?php

namespace App\Repository;

interface StaffRepositoryInterface extends EloquentRepositoryInterface
{

}
