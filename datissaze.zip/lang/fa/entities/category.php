<?php

return [
    'success.add' => 'دسته بندی با موفقیت افزوده شد',
    'success.update' => 'دسته بندی با موفقیت ویرایش شد',
    'success.delete' => 'دسته بندی با موفقیت حذف شد',
];
