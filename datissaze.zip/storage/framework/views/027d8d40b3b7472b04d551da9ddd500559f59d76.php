<?php $__env->startSection('content'); ?>

    <?php if (isset($component)) { $__componentOriginal8c1144be5cca1652e6eadb4ce3d3a22be6f264d7 = $component; } ?>
<?php $component = App\View\Components\Front\Header\Slider::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('front.header.slider'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Front\Header\Slider::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8c1144be5cca1652e6eadb4ce3d3a22be6f264d7)): ?>
<?php $component = $__componentOriginal8c1144be5cca1652e6eadb4ce3d3a22be6f264d7; ?>
<?php unset($__componentOriginal8c1144be5cca1652e6eadb4ce3d3a22be6f264d7); ?>
<?php endif; ?>

    <?php if (isset($component)) { $__componentOriginalfd2a5256309a74cd3d30a96c89b00d35a27aeebc = $component; } ?>
<?php $component = App\View\Components\Front\Intro\Section::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('front.intro.section'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Front\Intro\Section::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalfd2a5256309a74cd3d30a96c89b00d35a27aeebc)): ?>
<?php $component = $__componentOriginalfd2a5256309a74cd3d30a96c89b00d35a27aeebc; ?>
<?php unset($__componentOriginalfd2a5256309a74cd3d30a96c89b00d35a27aeebc); ?>
<?php endif; ?>

    <?php if (isset($component)) { $__componentOriginal4b5c47c47a5e9aa13d08a01bc40565044e92c961 = $component; } ?>
<?php $component = App\View\Components\Front\Services\Home::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('front.services.home'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Front\Services\Home::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4b5c47c47a5e9aa13d08a01bc40565044e92c961)): ?>
<?php $component = $__componentOriginal4b5c47c47a5e9aa13d08a01bc40565044e92c961; ?>
<?php unset($__componentOriginal4b5c47c47a5e9aa13d08a01bc40565044e92c961); ?>
<?php endif; ?>

    <?php if (isset($component)) { $__componentOriginaledffa1264e627b8eabda0a6e15d3c075132d2eb3 = $component; } ?>
<?php $component = App\View\Components\Front\Articles\Home::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('front.articles.home'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Front\Articles\Home::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaledffa1264e627b8eabda0a6e15d3c075132d2eb3)): ?>
<?php $component = $__componentOriginaledffa1264e627b8eabda0a6e15d3c075132d2eb3; ?>
<?php unset($__componentOriginaledffa1264e627b8eabda0a6e15d3c075132d2eb3); ?>
<?php endif; ?>

    <?php if (isset($component)) { $__componentOriginal2775b7eed2b9e8ea12c77539b658b9b6124f771b = $component; } ?>
<?php $component = App\View\Components\Front\Projects\Home::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('front.projects.home'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Front\Projects\Home::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2775b7eed2b9e8ea12c77539b658b9b6124f771b)): ?>
<?php $component = $__componentOriginal2775b7eed2b9e8ea12c77539b658b9b6124f771b; ?>
<?php unset($__componentOriginal2775b7eed2b9e8ea12c77539b658b9b6124f771b); ?>
<?php endif; ?>

    <?php if (isset($component)) { $__componentOriginal7f6e435b97a9b78e4dabdda6479e49ef57ba684c = $component; } ?>
<?php $component = App\View\Components\Front\Cooperators\Home::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('front.cooperators.home'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Front\Cooperators\Home::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7f6e435b97a9b78e4dabdda6479e49ef57ba684c)): ?>
<?php $component = $__componentOriginal7f6e435b97a9b78e4dabdda6479e49ef57ba684c; ?>
<?php unset($__componentOriginal7f6e435b97a9b78e4dabdda6479e49ef57ba684c); ?>
<?php endif; ?>

    <?php if (isset($component)) { $__componentOriginal1fe5ebe1abfce2d0537bd7087e14be149e698d20 = $component; } ?>
<?php $component = App\View\Components\Front\Team\Home::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('front.team.home'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Front\Team\Home::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1fe5ebe1abfce2d0537bd7087e14be149e698d20)): ?>
<?php $component = $__componentOriginal1fe5ebe1abfce2d0537bd7087e14be149e698d20; ?>
<?php unset($__componentOriginal1fe5ebe1abfce2d0537bd7087e14be149e698d20); ?>
<?php endif; ?>

    <?php if (isset($component)) { $__componentOriginal6e411aaa3ac56d2695ab24d0058653e6909c21dc = $component; } ?>
<?php $component = App\View\Components\Front\News\Home::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('front.news.home'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Front\News\Home::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6e411aaa3ac56d2695ab24d0058653e6909c21dc)): ?>
<?php $component = $__componentOriginal6e411aaa3ac56d2695ab24d0058653e6909c21dc; ?>
<?php unset($__componentOriginal6e411aaa3ac56d2695ab24d0058653e6909c21dc); ?>
<?php endif; ?>

    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.front.contact.section','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('front.contact.section'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('front.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\git\projects\Blogs\datissaze\resources\views/front/index.blade.php ENDPATH**/ ?>