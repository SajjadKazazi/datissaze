<?php

return [
    'success.add' => 'صفحه با موفقیت افزوده شد',
    'success.update' => 'صفحه با موفقیت ویرایش شد',
    'success.delete' => 'صفحه با موفقیت حذف شد',
];
