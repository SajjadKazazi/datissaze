<?php

return [

    'success.delete' => 'درخواست با موفقیت حذف شد',
];
