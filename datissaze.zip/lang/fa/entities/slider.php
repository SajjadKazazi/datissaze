<?php

return [
    'success.add' => 'اسلایدر با موفقیت افزوده شد',
    'success.update' => 'اسلایدر با موفقیت ویرایش شد',
    'success.delete' => 'اسلایدر با موفقیت حذف شد',
];
