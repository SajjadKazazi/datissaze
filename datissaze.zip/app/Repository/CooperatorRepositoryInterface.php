<?php

namespace App\Repository;

interface CooperatorRepositoryInterface extends EloquentRepositoryInterface
{

}
