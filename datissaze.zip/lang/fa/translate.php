<?php
return [
    'book' => [
        'properties' => 'ویژگی ها',
        'view' => 'مشاهده کتاب',
    ],
    'video' => [
        'properties' => 'ویژگی ها',
        'view' => 'مشاهده دوره',
    ],
    'money' => 'تومان',
    'payableAmount' => 'مبلغ قابل پرداخت',
    'pay' => 'پرداخت',
    'total' => 'جمع کل',
    'demo' => 'دمو',
    'order_status' => [
        'BASKET' => 'در سبد خرید',
        'SUCCESS' => 'موفق',
        'FAILED' => 'ناموفق',
        'CHECKOUT' => 'متنظر پرداخت'
    ]
];
