<?php

namespace App\Repositories\Admin;

use Prettus\Repository\Contracts\RepositoryInterface;

/**
 * Interface PortfolioRepository.
 *
 * @package namespace App\Repositories\\Admin;
 */
interface StaffRepository extends RepositoryInterface
{
    //
}
