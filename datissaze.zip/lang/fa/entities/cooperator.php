<?php

return [
    'success.add' => 'شرکت با موفقیت افزوده شد',
    'success.update' => 'شرکت با موفقیت ویرایش شد',
    'success.delete' => 'شرکت با موفقیت حذف شد',
];
