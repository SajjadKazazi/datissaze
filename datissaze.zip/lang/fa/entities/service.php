<?php

return [
    'success.add' => 'سرویس با موفقیت افزوده شد',
    'success.update' => 'سرویس با موفقیت ویرایش شد',
    'success.delete' => 'سرویس با موفقیت حذف شد',
];
